/*
06.Write a program that takes radius of a circle as input.
Read the entered radius using Scanner class. Then calculate and
print the area and circumference of the circle.
*/
import java.util.*;
class Que6{
    public static void main(String args[]){
      double r,area,circum;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter the radius: ");
      r = sc.nextInt();
      
      area = 3.14 * r * r;
      System.out.println("Area of Circle is: "+area);
      
      circum = 2 * 3.14 * r;
      System.out.println("Circumference of Circle is: "+circum);
    }

}