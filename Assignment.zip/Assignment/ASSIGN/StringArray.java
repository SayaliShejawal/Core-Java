class StringArray{
	public static void main(String args[]){
		
		String s[] = {"Shankar","Bhushan","Swapnil","Lad","Prathamesh"};
		
		for(String a : s){
			System.out.println(a);
		}
	}
	
}